﻿using Bio.Business.Models;
using FluentValidation;

namespace Bio.Business.Validations
{
    public class AlimentoSubstituicaoValidation : AbstractValidator<AlimentoSubstituicao>
    {
        public AlimentoSubstituicaoValidation()
        {

        }
    }
}
