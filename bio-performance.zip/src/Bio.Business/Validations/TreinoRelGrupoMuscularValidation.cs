﻿using Bio.Business.Models;
using FluentValidation;

namespace Bio.Business.Validations
{
    public class TreinoRelGrupoMuscularValidation : AbstractValidator<TreinoRelGrupoMuscular>
    {
        public TreinoRelGrupoMuscularValidation()
        {

        }
    }
}
