﻿namespace Bio.Business.Models.Enums
{
    public enum Genero
    {
        Masculino = 1,
        Feminino
    }
}
